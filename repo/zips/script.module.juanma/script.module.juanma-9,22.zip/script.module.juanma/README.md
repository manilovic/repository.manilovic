# script.module.juanma
TV addon to watch all TV Sports channel (included all spanish channels) 

Horus addon required to run this addon.
